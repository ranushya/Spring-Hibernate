package org.cts.main;

import org.cts.config.AppContext;
import org.cts.entity.Emp;
import org.cts.service.EmpServiceImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context=new AnnotationConfigApplicationContext(AppContext.class);
		EmpServiceImpl service=context.getBean("service", EmpServiceImpl.class);
		Integer eno=service.insert(new Emp(2,"suresh","chennai"));
		System.out.println(eno+" record inserted");
		
	}

}
