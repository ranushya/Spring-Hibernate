package org.cts.dao;

import org.cts.entity.Emp;

public interface EmpDao {
	Integer insert(Emp e);

}
