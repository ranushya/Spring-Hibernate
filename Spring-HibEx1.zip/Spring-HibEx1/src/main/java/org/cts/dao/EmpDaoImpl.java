package org.cts.dao;
import org.cts.entity.Emp;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Repository
public class EmpDaoImpl implements EmpDao {
	@Autowired
	SessionFactory factory;
	
	public void setFactory(SessionFactory factory) {
		this.factory = factory;
	}

	@Override
	@Transactional
	public Integer insert(Emp e) {
		Session session=factory.getCurrentSession();
		Integer no=(Integer)session.save(e);
		
		return no;
	}

}
