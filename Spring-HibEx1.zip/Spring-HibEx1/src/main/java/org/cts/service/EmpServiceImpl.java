package org.cts.service;
import org.cts.dao.EmpDao;
import org.cts.entity.Emp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("service")
public class EmpServiceImpl implements EmpService {
	@Autowired
	EmpDao dao;
	
	public void setDao(EmpDao dao) {
		this.dao = dao;
	}

	@Override
	public Integer insert(Emp e) {
		int eno=dao.insert(e);
		return eno;
	}

}
