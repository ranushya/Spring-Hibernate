package org.cts.service;

import org.cts.entity.Emp;

public interface EmpService {
	Integer insert(Emp e);
}
