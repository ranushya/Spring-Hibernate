package org.cts.client;

import org.cts.entity.Emp;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		Configuration configuration=new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory factory=configuration.buildSessionFactory();
		Session session=factory.openSession();
		Emp e=session.get(Emp.class, 1);
		session.evict(e);
		Emp e1=session.get(Emp.class, 1);
		//Emp e=session.get(Emp.class, 10);
		
		System.out.println(e.getEno()+"\t"+e.getName()+"\t"+e.getAddress());
		System.out.println(e1.getEno()+"\t"+e1.getName()+"\t"+e1.getAddress());
		session.close();
	}

}
