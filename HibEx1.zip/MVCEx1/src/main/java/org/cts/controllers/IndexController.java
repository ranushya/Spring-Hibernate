package org.cts.controllers;


import org.cts.model.Emp;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/student")
public class IndexController {
	@RequestMapping("/showForm")
	public String getIndex(Model model)
	{
		model.addAttribute("emp", new Emp());
		return "index";
	}

	/*
	 * @RequestMapping("/processForm") public String processForm(HttpServletRequest
	 * request,Model model) { String name=request.getParameter("name");
	 * model.addAttribute("name", name); return "index";
	 * 
	 * }
	 */
	@RequestMapping("/processForm")
	public String processForm(@ModelAttribute("emp") Emp e,Model model)
	{
		model.addAttribute("e", e);
		return "index";
		
	}
}
