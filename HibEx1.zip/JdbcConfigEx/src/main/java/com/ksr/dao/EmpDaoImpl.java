package com.ksr.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ksr.entity.Emp;
@Repository
public class EmpDaoImpl implements EmpDao {

	@Autowired
	DataSource dataSource;
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	@Override
	public int insert(Emp e) {
		Connection con=null;
		PreparedStatement pst=null;
		int i=0;
		try {
			con=dataSource.getConnection();
			if(con!=null)
			{
				pst=con.prepareStatement("insert into emp values(?,?,?)");
				pst.setInt(1, e.getEno());
				pst.setString(2, e.getName());
				pst.setString(3, e.getAddress());
				i=pst.executeUpdate();
				
			}
			con.close();
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		return i;
	}

}
