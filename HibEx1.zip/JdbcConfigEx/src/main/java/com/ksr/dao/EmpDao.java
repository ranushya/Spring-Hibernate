package com.ksr.dao;

import com.ksr.entity.Emp;

public interface EmpDao {
	int insert(Emp e);
}
