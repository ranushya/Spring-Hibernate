package com.ksr.service;

import com.ksr.entity.Emp;

public interface EmpService {
	int insert(Emp e);
	

}
