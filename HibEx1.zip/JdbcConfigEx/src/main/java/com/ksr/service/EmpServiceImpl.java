package com.ksr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ksr.dao.EmpDao;
import com.ksr.entity.Emp;
@Service("service")
public class EmpServiceImpl implements EmpService {
	@Autowired
	EmpDao dao;
	public void setDao(EmpDao dao) {
		this.dao = dao;
	}
	@Override
	public int insert(Emp e) {
		int i=dao.insert(e);
		return i;
	}
}
