package com.ksr.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ksr.config.AppConfig;
import com.ksr.entity.Emp;
import com.ksr.service.EmpServiceImpl;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
		EmpServiceImpl service=context.getBean("service",EmpServiceImpl.class);
		int i=service.insert(new Emp(4,"ram","chennai"));
		if(i>0)
			System.out.println("inserted");
		else
			System.out.println("not inserted");
	}

}
