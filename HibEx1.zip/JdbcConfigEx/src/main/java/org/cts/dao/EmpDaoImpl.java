package org.cts.dao;

import java.util.List;

import org.cts.Emp;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Repository
public class EmpDaoImpl implements EmpDaoI {
	@Autowired
	SessionFactory factory;
	
	public void setFactory(SessionFactory factory) {
		this.factory = factory;
	}

	@Override
	@Transactional
	public int insert(Emp e) {
		Session session=factory.getCurrentSession();
		Integer i=(Integer)session.save(e);
		return i;
	}

	@Override
	public Emp getEmp(int eno) {
		Session session=factory.getCurrentSession();
		Emp e=session.get(Emp.class, eno);
		return e;
	}

	@Override
	public List<Emp> getEmployees() {
		Session session=factory.getCurrentSession();
		Query query=session.createQuery("select e from org.cts.Emp e");
		List<Emp> emps=query.list();
		return emps;
	}

}
