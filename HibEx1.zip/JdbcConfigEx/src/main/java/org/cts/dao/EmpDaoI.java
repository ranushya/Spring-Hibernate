package org.cts.dao;

import java.util.List;

import org.cts.Emp;

public interface EmpDaoI 
{
	int insert(Emp e);
	Emp getEmp(int eno);
	List<Emp> getEmployees();

}
