package org.cts.main;
import org.cts.Emp;
import org.cts.config.AppConfig;
import org.cts.service.EmpServiceImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test 
{
	public static void main(String[] args) 
	{
		ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
		EmpServiceImpl service=context.getBean(EmpServiceImpl.class,"service");
		//inserting an object
		Emp e=new Emp(2, "suresh", "chennai");
		int i=service.save(e);
		System.out.println("record with "+i+" inserted successfully");
		
	}

}
