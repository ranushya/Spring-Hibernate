package org.cts.service;

import java.util.List;

import org.cts.Emp;

public interface EmpServiceI {
	int save(Emp e);
	Emp get(int eno);
	List<Emp> getEmployees();
	
}
