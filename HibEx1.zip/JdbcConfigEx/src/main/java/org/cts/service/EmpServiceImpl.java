package org.cts.service;

import java.util.List;

import org.cts.Emp;
import org.cts.dao.EmpDaoI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("service")
public class EmpServiceImpl implements EmpServiceI {
	@Autowired
	EmpDaoI dao;
	
	public void setDao(EmpDaoI dao) {
		this.dao = dao;
	}
	@Override
	public int save(Emp e) {
		int i=dao.insert(e);
		return i;
	}
	@Override
	public Emp get(int eno) {
		Emp e=dao.getEmp(eno);
		return e;
	}
	@Override
	public List<Emp> getEmployees() {
		List<Emp> emps=dao.getEmployees();
		return emps;
	}

}
