package org.cts.controller;

import org.cts.entity.Student;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/student")
public class StudentController {
	/*
	 * @RequestMapping("/show") public String showIndex(Model model) { Student
	 * st=new Student(); model.addAttribute("student",st); return "index"; }
	 */
	@RequestMapping("/show")
	public String showForm(ModelMap map)
	{
		/*
		 * Student st=new Student(); ModelAndView mv=new ModelAndView();
		 * mv.addObject(st); mv.setViewName("index"); return mv;
		 */
		
		map.put("student", new Student());
		return "index";
		
	}
	@RequestMapping("/processForm")
	public String processForm(@ModelAttribute("student") Student student,Model model)
	{
		return "student-confirm";
	}
}
