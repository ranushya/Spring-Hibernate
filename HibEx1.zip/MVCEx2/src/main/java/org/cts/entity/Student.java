package org.cts.entity;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Student {
	private int sno;
	private String name;
	private String address;
	private String country;
	Map<String, String> countries=null;
	List<String> genders=null;
	List<String> c=null;
	String courses[];
	String gender;
	
	public Student()
	{
		countries=new LinkedHashMap<>();
		countries.put("IN", "India");
		countries.put("Bz", "Brazil");
		countries.put("US", "United States Of America");
		genders=new ArrayList<>();
		genders.add("Male");
		genders.add("FeMale");
		c=new ArrayList<>();
		c.add("java");
		c.add(".net");
		c.add("python");
	}
	public Student(int sno, String name, String address) {
		super();
		this.sno = sno;
		this.name = name;
		this.address = address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public void setCountries(Map<String, String> countries) {
		this.countries = countries;
	}
	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Map<String, String> getCountries() {
		return countries;
	}
	public List<String> getGenders() {
		return genders;
	}
	public String[] getCourses() {
		return courses;
	}
	public void setCourses(String[] courses) {
		this.courses = courses;
	}
	public void setGenders(List<String> genders) {
		this.genders = genders;
	}
	public List<String> getC() {
		return c;
	}
}
