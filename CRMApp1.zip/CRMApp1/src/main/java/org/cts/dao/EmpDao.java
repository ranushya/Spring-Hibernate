package org.cts.dao;

import org.cts.entity.Emp;

public interface EmpDao {
	int insert(Emp e);
}
