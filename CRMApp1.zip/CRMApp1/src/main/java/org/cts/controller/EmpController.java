package org.cts.controller;

import org.cts.entity.Emp;
import org.cts.service.EmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/emp")
public class EmpController {
	@Autowired
	EmpService service;
	
	public void setService(EmpService service) {
		this.service = service;
	}
	@RequestMapping("/show")
	public String showForm(ModelMap map)
	{
		map.put("emp", new Emp());
		return "emp-form";
	}
	@RequestMapping("/processForm")
	public String submitForm(@ModelAttribute("emp") Emp e,ModelMap map)
	{
		int i=service.register(e);
		if(i>0)
			map.put("msg", "succcessfully inserted");
		else
			map.put("msg", "not inserted");
		return "emp-form";
	}
}
