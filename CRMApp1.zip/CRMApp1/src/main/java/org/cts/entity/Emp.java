package org.cts.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="emp4")
public class Emp {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int eno;
	private String name;
	private String address;
	private String email;
	private String gender;
	private int sal;
	public Emp()
	{
		
	}
	public Emp(int eno, String name, String address, String email, String gender,int sal) {
		super();
		this.eno = eno;
		this.name = name;
		this.address = address;
		this.email = email;
		this.gender = gender;
		this.sal = sal;
	}
	public int getEno() {
		return eno;
	}
	public void setEno(int eno) {
		this.eno = eno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	
	
}
