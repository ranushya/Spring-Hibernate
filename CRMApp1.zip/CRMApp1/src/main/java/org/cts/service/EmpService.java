package org.cts.service;

import org.cts.entity.Emp;

public interface EmpService {
	int register(Emp e);
}
