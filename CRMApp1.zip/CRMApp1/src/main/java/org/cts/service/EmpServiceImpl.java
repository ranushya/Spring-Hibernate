package org.cts.service;

import org.cts.dao.EmpDao;
import org.cts.entity.Emp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
public class EmpServiceImpl implements EmpService {
	@Autowired
	EmpDao dao;
	
	public void setDao(EmpDao dao) {
		this.dao = dao;
	}

	@Override
	@Transactional
	public int register(Emp e) {
		int i=dao.insert(e);
		return i;
	}

}
